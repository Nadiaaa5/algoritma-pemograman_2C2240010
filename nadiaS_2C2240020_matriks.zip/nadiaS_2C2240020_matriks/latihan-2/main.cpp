#include <iostream>

using namespace std;

int main() {
    int baris, kolom, jumlah_elemen;

    cout << "Masukkan jumlah baris matriks: ";
    cin >> baris;

    cout << "Masukkan jumlah kolom matriks: ";
    cin >> kolom;

    // Jumlah elemen dalam matriks adalah hasil perkalian baris dan kolom
    jumlah_elemen = baris * kolom;

    cout << "Jumlah elemen dalam matriks adalah: " << jumlah_elemen << endl;

    return 0;
}

