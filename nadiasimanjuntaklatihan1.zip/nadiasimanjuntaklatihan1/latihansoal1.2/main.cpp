#include <iostream>
using namespace std;

int main() {
    int jumlahjamkerja;
    int kekuranganjam;
    int lembur;
    int upah;

    cout << "masukkan jumlah jam kerja per minggu: ";
    cin >> jumlahjamkerja;

    if (jumlahjamkerja >= 40) {
        lembur = jumlahjamkerja - 40;
        upah = 40*1000 + lembur*2000;
    }
    else {
        kekuranganjam = 40 - jumlahjamkerja;
        upah = jumlahjamkerja*1000 - kekuranganjam*500;
    }
    cout << "upah per minggu";
    cout << upah;

    return 0;
}




