#include <iostream>
using namespace std;

int main() {
    int A;
    int B;
    char pilihan;

    cout << "masukkan bilangan pertama (A) = ";
    cin >> A;
    cout << "masukkan bilangan kedua (B) = ";
    cin >> B;
    cout << "masukkan pilihan operasi = ";
    cin >> pilihan;
    switch (pilihan) {

        case 'a' : cout << "A + B = " << A + B << endl; break;
        case 'b' : cout << "A - B = " << A - B << endl; break;
        case 'c' : cout << "A * B = " << A * B << endl; break;
        case 'd' : cout << "A / B = " << (float)A / (float)B << endl; break;
        case 'e' : cout << "A div B = " << A / B << endl; break;
        case 'f' : cout << "A mod B = " << A % B << endl; break;
        case 'h' : cout << "bukan pilihan menu yang benar" << endl; break;
    }
    return 0;
}
