#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "masukkan berat badan atlet: ";
    cin >> n;

    if (n < 45) {
        cout << "tidak memenuhi kualifikasi";

        return 1;
    }

    if (n <= 50) {
        cout << "kelas A";
    }
    else if (n <= 55) {
        cout << "kelas B";
    }
    else if (n <= 60) {
        cout << "kelas C";
    }
    else if (n <= 65) {
        cout << "kelas D";
    }
    else if (n <= 70) {
        cout << "kelas E";
    }
    else {
        cout << "kelas F";
    }
    return 0;
}

